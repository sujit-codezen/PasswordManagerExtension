async function savePassword(site, username, password, masterPassword) {
  const { encryptedData, iv } = await encryptData(`${username}:${password}`, masterPassword);
  chrome.runtime.sendMessage({
    action: 'savePassword',
    site,
    encryptedData: {
      data: encryptedData,
      iv: Array.from(iv)
    }
  });
}

// Background script stores this data in chrome.storage.local
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'savePassword') {
    chrome.storage.local.get('passwords', function (result) {
      let passwords = result.passwords || {};
      passwords[request.site] = request.encryptedData;
      chrome.storage.local.set({ passwords });
      sendResponse({ status: 'success' });
    });
    return true; // Keep the message channel open for sendResponse
  }
});


async function getAllPasswords(masterPassword) {
  return new Promise((resolve) => {
    chrome.storage.local.get('passwords', async function (result) {
      let passwords = [];
      for (let site in result.passwords) {
        const { data, iv } = result.passwords[site];
        const decrypted = await decryptData(data, new Uint8Array(iv), masterPassword);
        const [username, password] = decrypted.split(':');
        passwords.push({ site, username, password });
      }
      resolve(passwords);
    });
  });
}

